# Phase 4: Allow Complex Styling in Notes (1 day)

## Rails
### Models

### Controllers

### Views

## Flux
### Views (React Components)

### Stores

### Actions

## Gems/Libraries
* react-quill (npm)